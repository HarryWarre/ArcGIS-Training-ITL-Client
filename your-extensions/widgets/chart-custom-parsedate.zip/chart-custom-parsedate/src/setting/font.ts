export const fontList = [
  "Arial",
  "Verdana",
  "Tahoma",
  "Times New Roman",
  "Courier New",
  "Georgia",
  "Trebuchet MS",
  "Lucida Console",
  // "Roboto", //Not support this font
  // "Open Sans"
];
